import DashboardComponent from './DashboardComponent';

export default DashboardComponent;
