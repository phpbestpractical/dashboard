import LoadingComponent from './LoadingComponent';

export default LoadingComponent;
