import React from 'react'
import { Column, Row } from 'simple-flexbox';
import './custom.css'
const Company = () => {
  return (
    <div className='companyContainer'>
      <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img  height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor'>Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img  height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor' >Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img  height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor' >Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor'>Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img  height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor'>Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img  height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor' >Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img  height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor' >Shortcuts</span>
        </Row>
        </Column>
        <Column>
        <Row horizontal='left' vertical='center' 
        breakpoints={{ 1024: 'column' }}
        className="row">
        <img height='25px' width='27px' src={require('./../../assets/icons/iconstat.png')} />
            <span className='rowColor'>Shortcuts</span>
        </Row>
        </Column>
        {/* <img className='companylogo' src='https://www.bing.com/th?id=AMMS_6e4e8567f9a00325e103a60ca1b62ff9&w=156&h=112&c=7&o=6&dpr=1.5&pid=SANGAM' />
        <img className='companylogo' src='https://applitools.com/wp-content/uploads/2018/07/Jira-new-logo.png' />
        <img className='companylogo' src='https://www.bing.com/th?id=AMMS_6e4e8567f9a00325e103a60ca1b62ff9&w=156&h=112&c=7&o=6&dpr=1.5&pid=SANGAM' />
        <img className='companylogo' src='https://www.bing.com/th?id=AMMS_6e4e8567f9a00325e103a60ca1b62ff9&w=156&h=112&c=7&o=6&dpr=1.5&pid=SANGAM' /> */}
    </div>
  )
}

export default Company